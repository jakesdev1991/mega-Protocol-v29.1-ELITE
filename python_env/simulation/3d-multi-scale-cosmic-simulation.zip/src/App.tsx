import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

type Phase = {
  key: string;
  title: string;
  summary: string;
};

type HudState = {
  phaseIndex: number;
  progress: number;
  metrics: [string, string][];
};

const PHASES: Phase[] = [
  {
    key: "micro",
    title: "Micro Layer: Quantum Relational Lattice",
    summary:
      "Q-region nodes exchange directional overlap and build a distance graph where locality appears from information density.",
  },
  {
    key: "accretion",
    title: "Meso Layer: Stellar Ignition and Planetary Assembly",
    summary:
      "A collapsing disk self-organizes into a star, protoplanets migrate, and debris clears into stable orbital resonances.",
  },
  {
    key: "planetary",
    title: "System Layer: Mature Planetary Dynamics",
    summary:
      "Orbit precession, moon-locking, and comet transfer shape long-horizon stability for full planetary systems.",
  },
  {
    key: "galactic",
    title: "Macro Layer: Galactic Interaction and Merger",
    summary:
      "Spiral galaxies approach, tidal streams form, and cores slingshot as angular momentum redistributes across kiloparsecs.",
  },
  {
    key: "cosmic",
    title: "Ultra-Macro Layer: Cluster Web and Expansion",
    summary:
      "Galaxy clusters ride filamentary structure while spacetime expansion stretches proper distance between large-scale nodes.",
  },
];

const createSpiralGalaxy = (count: number, color: number) => {
  const positions = new Float32Array(count * 3);
  const arms = 4;
  for (let i = 0; i < count; i += 1) {
    const radius = Math.pow(Math.random(), 0.6) * 26;
    const arm = (i % arms) * ((Math.PI * 2) / arms);
    const spin = radius * 0.45;
    const jitter = (Math.random() - 0.5) * 0.7;
    const angle = arm + spin + jitter;
    const y = (Math.random() - 0.5) * (1.2 + radius * 0.03);
    positions[i * 3] = Math.cos(angle) * radius;
    positions[i * 3 + 1] = y;
    positions[i * 3 + 2] = Math.sin(angle) * radius;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const material = new THREE.PointsMaterial({
    color,
    size: 0.2,
    transparent: true,
    opacity: 0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });

  return new THREE.Points(geometry, material);
};

export default function App() {
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const [hud, setHud] = useState<HudState>({
    phaseIndex: 0,
    progress: 0,
    metrics: [
      ["Quotient metric D", "0.000"],
      ["Asymmetry field Phi_D", "0.000"],
      ["Orbital coherence", "0.000"],
      ["Large-scale growth", "0.000"],
    ],
  });

  const phaseTicks = useMemo(() => PHASES.map((phase) => phase.title.split(":")[0]), []);

  useEffect(() => {
    if (!canvasRef.current) {
      return undefined;
    }

    const host = canvasRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x01030a);
    scene.fog = new THREE.FogExp2(0x01030a, 0.0016);

    const camera = new THREE.PerspectiveCamera(58, host.clientWidth / host.clientHeight, 0.1, 4000);
    camera.position.set(0, 28, 110);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(host.clientWidth, host.clientHeight);
    host.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.04;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.18;
    controls.minDistance = 40;
    controls.maxDistance = 280;

    scene.add(new THREE.AmbientLight(0xffffff, 0.24));
    const rimLight = new THREE.DirectionalLight(0x8bc5ff, 1.05);
    rimLight.position.set(40, 40, -25);
    scene.add(rimLight);

    const systems = {
      micro: new THREE.Group(),
      accretion: new THREE.Group(),
      planetary: new THREE.Group(),
      galactic: new THREE.Group(),
      cosmic: new THREE.Group(),
    };

    Object.values(systems).forEach((group) => scene.add(group));

    const setGroupOpacity = (group: THREE.Group, target: number) => {
      group.traverse((obj: THREE.Object3D) => {
        const candidate = obj as THREE.Object3D & {
          material?: THREE.Material | THREE.Material[];
        };

        if (!candidate.material) {
          return;
        }

        const mats = Array.isArray(candidate.material) ? candidate.material : [candidate.material];
        mats.forEach((mat: THREE.Material) => {
          if (!("opacity" in mat)) {
            return;
          }
          mat.transparent = true;
          mat.opacity += (target - mat.opacity) * 0.06;
        });
      });
    };

    const starfieldGeo = new THREE.BufferGeometry();
    const stars = new Float32Array(5000 * 3);
    for (let i = 0; i < 5000; i += 1) {
      const radius = 650 + Math.random() * 1200;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      stars[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      stars[i * 3 + 1] = radius * Math.cos(phi);
      stars[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    }
    starfieldGeo.setAttribute("position", new THREE.BufferAttribute(stars, 3));
    const starfield = new THREE.Points(
      starfieldGeo,
      new THREE.PointsMaterial({ color: 0xa7c5ff, size: 0.95, transparent: true, opacity: 0.65 }),
    );
    scene.add(starfield);

    const microPointsCount = 1000;
    const microPos = new Float32Array(microPointsCount * 3);
    const microVel = new Float32Array(microPointsCount * 3);
    for (let i = 0; i < microPointsCount; i += 1) {
      const r = Math.cbrt(Math.random()) * 40;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      microPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      microPos[i * 3 + 1] = r * Math.cos(phi);
      microPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      microVel[i * 3] = (Math.random() - 0.5) * 0.03;
      microVel[i * 3 + 1] = (Math.random() - 0.5) * 0.03;
      microVel[i * 3 + 2] = (Math.random() - 0.5) * 0.03;
    }
    const microGeometry = new THREE.BufferGeometry();
    microGeometry.setAttribute("position", new THREE.BufferAttribute(microPos, 3));
    const microCloud = new THREE.Points(
      microGeometry,
      new THREE.PointsMaterial({
        color: 0x4de8ff,
        size: 0.45,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    systems.micro.add(microCloud);

    const edgeSegments = 1800;
    const edgePos = new Float32Array(edgeSegments * 6);
    for (let i = 0; i < edgeSegments; i += 1) {
      const a = Math.floor(Math.random() * microPointsCount);
      const b = (a + 1 + Math.floor(Math.random() * 30)) % microPointsCount;
      edgePos[i * 6] = microPos[a * 3];
      edgePos[i * 6 + 1] = microPos[a * 3 + 1];
      edgePos[i * 6 + 2] = microPos[a * 3 + 2];
      edgePos[i * 6 + 3] = microPos[b * 3];
      edgePos[i * 6 + 4] = microPos[b * 3 + 1];
      edgePos[i * 6 + 5] = microPos[b * 3 + 2];
    }
    const microEdges = new THREE.LineSegments(
      new THREE.BufferGeometry().setAttribute("position", new THREE.BufferAttribute(edgePos, 3)),
      new THREE.LineBasicMaterial({ color: 0x0e6ca7, transparent: true, opacity: 0 }),
    );
    systems.micro.add(microEdges);

    const coreStar = new THREE.Mesh(
      new THREE.SphereGeometry(6.8, 42, 42),
      new THREE.MeshStandardMaterial({ color: 0xffc861, emissive: 0xff7f22, emissiveIntensity: 1.1, transparent: true, opacity: 0 }),
    );
    systems.accretion.add(coreStar);

    const diskCount = 5000;
    const diskPos = new Float32Array(diskCount * 3);
    for (let i = 0; i < diskCount; i += 1) {
      const radius = 9 + Math.random() * 42;
      const theta = Math.random() * Math.PI * 2;
      const height = (Math.random() - 0.5) * (2.8 + radius * 0.035);
      diskPos[i * 3] = Math.cos(theta) * radius;
      diskPos[i * 3 + 1] = height;
      diskPos[i * 3 + 2] = Math.sin(theta) * radius;
    }
    const diskGeometry = new THREE.BufferGeometry();
    diskGeometry.setAttribute("position", new THREE.BufferAttribute(diskPos, 3));
    const diskCloud = new THREE.Points(
      diskGeometry,
      new THREE.PointsMaterial({
        color: 0xf4b16c,
        size: 0.26,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    systems.accretion.add(diskCloud);

    const orbitRingRadii = [16, 24, 33, 44];
    orbitRingRadii.forEach((radius) => {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(radius - 0.08, radius + 0.08, 96),
        new THREE.MeshBasicMaterial({ color: 0x5f7ea6, side: THREE.DoubleSide, transparent: true, opacity: 0 }),
      );
      ring.rotation.x = Math.PI / 2;
      systems.planetary.add(ring);
    });

    const planetDefs = [
      { color: 0x77f2ff, radius: 1.4, orbit: 16, speed: 0.036, eccentricity: 0.05, tilt: 0.08 },
      { color: 0xb491ff, radius: 2.2, orbit: 24, speed: 0.021, eccentricity: 0.08, tilt: 0.15 },
      { color: 0xf58f78, radius: 2.8, orbit: 33, speed: 0.016, eccentricity: 0.11, tilt: 0.04 },
      { color: 0x9de39f, radius: 2, orbit: 44, speed: 0.012, eccentricity: 0.06, tilt: 0.1 },
    ];

    const planets = planetDefs.map((def, index) => {
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(def.radius, 24, 24),
        new THREE.MeshStandardMaterial({
          color: def.color,
          roughness: 0.6,
          metalness: 0.12,
          transparent: true,
          opacity: 0,
        }),
      );
      systems.planetary.add(mesh);
      return {
        mesh,
        angle: index * 1.1,
        speed: def.speed,
        orbit: def.orbit,
        eccentricity: def.eccentricity,
        tilt: def.tilt,
      };
    });

    const moon = new THREE.Mesh(
      new THREE.SphereGeometry(0.5, 14, 14),
      new THREE.MeshStandardMaterial({ color: 0xe5ecff, roughness: 0.75, transparent: true, opacity: 0 }),
    );
    systems.planetary.add(moon);

    const cometTrailCount = 800;
    const cometPos = new Float32Array(cometTrailCount * 3);
    const cometPhase = new Float32Array(cometTrailCount);
    for (let i = 0; i < cometTrailCount; i += 1) {
      cometPhase[i] = Math.random() * Math.PI * 2;
      cometPos[i * 3] = 0;
      cometPos[i * 3 + 1] = -999;
      cometPos[i * 3 + 2] = 0;
    }
    const cometGeo = new THREE.BufferGeometry();
    cometGeo.setAttribute("position", new THREE.BufferAttribute(cometPos, 3));
    const cometCloud = new THREE.Points(
      cometGeo,
      new THREE.PointsMaterial({
        color: 0xd3f4ff,
        size: 0.18,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    systems.planetary.add(cometCloud);

    const galaxyA = new THREE.Group();
    const galaxyB = new THREE.Group();
    galaxyA.add(createSpiralGalaxy(7000, 0x5ac8ff));
    galaxyA.add(
      new THREE.Mesh(
        new THREE.SphereGeometry(2.6, 18, 18),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0 }),
      ),
    );
    galaxyB.add(createSpiralGalaxy(7000, 0xe8a6ff));
    galaxyB.add(
      new THREE.Mesh(
        new THREE.SphereGeometry(2.3, 18, 18),
        new THREE.MeshBasicMaterial({ color: 0xfff2d1, transparent: true, opacity: 0 }),
      ),
    );
    systems.galactic.add(galaxyA);
    systems.galactic.add(galaxyB);

    const bridgeGeo = new THREE.BufferGeometry();
    const bridgePos = new Float32Array(2000 * 3);
    bridgeGeo.setAttribute("position", new THREE.BufferAttribute(bridgePos, 3));
    const bridge = new THREE.Points(
      bridgeGeo,
      new THREE.PointsMaterial({
        color: 0xf4e3ff,
        size: 0.22,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    systems.galactic.add(bridge);

    const webNodes = 180;
    const webPos = new Float32Array(webNodes * 3);
    for (let i = 0; i < webNodes; i += 1) {
      webPos[i * 3] = (Math.random() - 0.5) * 220;
      webPos[i * 3 + 1] = (Math.random() - 0.5) * 130;
      webPos[i * 3 + 2] = (Math.random() - 0.5) * 220;
    }
    const webNodeGeometry = new THREE.BufferGeometry();
    webNodeGeometry.setAttribute("position", new THREE.BufferAttribute(webPos, 3));
    const webNodeCloud = new THREE.Points(
      webNodeGeometry,
      new THREE.PointsMaterial({ color: 0x9db8ff, size: 1.1, transparent: true, opacity: 0 }),
    );
    systems.cosmic.add(webNodeCloud);

    const webEdgePos = new Float32Array(360 * 6);
    for (let i = 0; i < 360; i += 1) {
      const a = Math.floor(Math.random() * webNodes);
      const b = Math.floor(Math.random() * webNodes);
      webEdgePos[i * 6] = webPos[a * 3];
      webEdgePos[i * 6 + 1] = webPos[a * 3 + 1];
      webEdgePos[i * 6 + 2] = webPos[a * 3 + 2];
      webEdgePos[i * 6 + 3] = webPos[b * 3];
      webEdgePos[i * 6 + 4] = webPos[b * 3 + 1];
      webEdgePos[i * 6 + 5] = webPos[b * 3 + 2];
    }
    const webEdges = new THREE.LineSegments(
      new THREE.BufferGeometry().setAttribute("position", new THREE.BufferAttribute(webEdgePos, 3)),
      new THREE.LineBasicMaterial({ color: 0x5e79d6, transparent: true, opacity: 0 }),
    );
    systems.cosmic.add(webEdges);

    const clock = new THREE.Clock();
    const cycleSeconds = 64;
    const phaseDuration = cycleSeconds / PHASES.length;
    let raf = 0;
    let lastHudPush = -100;

    const onResize = () => {
      if (!canvasRef.current) {
        return;
      }
      camera.aspect = canvasRef.current.clientWidth / canvasRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(canvasRef.current.clientWidth, canvasRef.current.clientHeight);
    };

    window.addEventListener("resize", onResize);

    const animate = () => {
      raf = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();
      const inCycle = elapsed % cycleSeconds;
      const phaseIndex = Math.min(PHASES.length - 1, Math.floor(inCycle / phaseDuration));
      const localProgress = (inCycle - phaseIndex * phaseDuration) / phaseDuration;
      const globalProgress = inCycle / cycleSeconds;

      const microPhase = phaseIndex === 0 ? 1 : 0;
      const accretionPhase = phaseIndex === 1 ? 1 : 0;
      const planetaryPhase = phaseIndex === 2 ? 1 : 0;
      const galacticPhase = phaseIndex === 3 ? 1 : 0;
      const cosmicPhase = phaseIndex === 4 ? 1 : 0;

      setGroupOpacity(systems.micro, microPhase);
      setGroupOpacity(systems.accretion, accretionPhase);
      setGroupOpacity(systems.planetary, planetaryPhase);
      setGroupOpacity(systems.galactic, galacticPhase);
      setGroupOpacity(systems.cosmic, cosmicPhase);

      for (let i = 0; i < microPointsCount; i += 1) {
        microPos[i * 3] += microVel[i * 3];
        microPos[i * 3 + 1] += microVel[i * 3 + 1];
        microPos[i * 3 + 2] += microVel[i * 3 + 2];
        const radius = Math.sqrt(
          microPos[i * 3] ** 2 + microPos[i * 3 + 1] ** 2 + microPos[i * 3 + 2] ** 2,
        );
        if (radius > 42) {
          microVel[i * 3] *= -1;
          microVel[i * 3 + 1] *= -1;
          microVel[i * 3 + 2] *= -1;
        }
      }
      (microGeometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      systems.micro.rotation.y += 0.0018;

      coreStar.scale.setScalar(1 + Math.sin(elapsed * 2.2) * 0.04);
      systems.accretion.rotation.y += 0.0015;
      const diskAttr = diskGeometry.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < diskCount; i += 1) {
        const x = diskAttr.array[i * 3] as number;
        const z = diskAttr.array[i * 3 + 2] as number;
        const angle = Math.atan2(z, x) + 0.0018 * (1 + 12 / (Math.hypot(x, z) + 6));
        const radius = Math.hypot(x, z);
        diskAttr.array[i * 3] = Math.cos(angle) * radius;
        diskAttr.array[i * 3 + 2] = Math.sin(angle) * radius;
      }
      diskAttr.needsUpdate = true;
      const diskMaterial = diskCloud.material as THREE.PointsMaterial;
      diskMaterial.opacity = 0.1 + (1 - localProgress) * 0.6 * accretionPhase;

      systems.planetary.rotation.y += 0.0009;
      planets.forEach((planet, idx) => {
        planet.angle += planet.speed;
        const migration = phaseIndex === 2 ? 1 - localProgress * 0.12 : 1;
        const orbit = planet.orbit * migration;
        const x = Math.cos(planet.angle) * orbit * (1 - planet.eccentricity);
        const z = Math.sin(planet.angle) * orbit * (1 + planet.eccentricity);
        const y = Math.sin(planet.angle * 2.2 + idx) * planet.tilt * orbit;
        planet.mesh.position.set(x, y, z);
        if (phaseIndex === 1) {
          planet.mesh.scale.setScalar(0.4 + localProgress * 0.6);
        } else {
          planet.mesh.scale.setScalar(1);
        }
      });
      moon.position.copy(planets[2].mesh.position);
      moon.position.x += Math.cos(elapsed * 1.8) * 3.5;
      moon.position.z += Math.sin(elapsed * 1.8) * 3.5;
      moon.position.y += Math.sin(elapsed * 3.1) * 0.8;

      const cometAttr = cometGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < cometTrailCount; i += 1) {
        const phase = cometPhase[i] + elapsed * 0.8;
        const radius = 34 + Math.sin(phase * 0.6) * 10;
        cometAttr.array[i * 3] = Math.cos(phase) * radius;
        cometAttr.array[i * 3 + 1] = Math.sin(phase * 1.7) * 2.3;
        cometAttr.array[i * 3 + 2] = Math.sin(phase) * radius;
      }
      cometAttr.needsUpdate = true;

      const merger = Math.min(1, Math.max(0, localProgress));
      const separation = phaseIndex === 3 ? THREE.MathUtils.lerp(118, 24, merger) : 118;
      galaxyA.position.set(-separation / 2, Math.sin(elapsed * 0.35) * 4, 0);
      galaxyB.position.set(separation / 2, -Math.sin(elapsed * 0.35) * 4, Math.sin(elapsed * 0.2) * 16);
      galaxyA.rotation.y += 0.0027;
      galaxyB.rotation.y -= 0.0022;
      galaxyA.rotation.x = 0.34;
      galaxyB.rotation.x = -0.28;

      const bridgeAttr = bridgeGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < 2000; i += 1) {
        const t = i / 1999;
        const arc = Math.sin(t * Math.PI);
        bridgeAttr.array[i * 3] = THREE.MathUtils.lerp(galaxyA.position.x, galaxyB.position.x, t);
        bridgeAttr.array[i * 3 + 1] = arc * 4 + Math.sin(elapsed * 0.5 + i * 0.03) * 0.6;
        bridgeAttr.array[i * 3 + 2] = Math.sin(t * Math.PI * 3 + elapsed * 0.5) * 4;
      }
      bridgeAttr.needsUpdate = true;
      (bridge.material as THREE.PointsMaterial).opacity = phaseIndex === 3 ? merger * 0.8 : 0;

      const expansion = phaseIndex === 4 ? 1 + localProgress * 1.8 : 1;
      systems.cosmic.scale.setScalar(expansion);
      systems.cosmic.rotation.y += 0.0014;

      if (elapsed - lastHudPush > 0.12) {
        lastHudPush = elapsed;
        const metrics: [string, string][] = [
          ["Quotient metric D", `${(0.12 + Math.abs(Math.sin(elapsed * 0.9)) * 0.4).toFixed(3)}`],
          ["Asymmetry field Phi_D", `${(0.3 + Math.abs(Math.cos(elapsed * 0.7)) * 0.6).toFixed(3)}`],
          ["Orbital coherence", `${(74 + Math.sin(elapsed * 0.8) * 22).toFixed(1)}%`],
          ["Large-scale growth", `${(1 + globalProgress * 8.4).toFixed(2)}x`],
        ];

        if (phaseIndex === 1) {
          metrics[2][1] = `${(localProgress * 100).toFixed(1)}% formed`;
        }
        if (phaseIndex === 3) {
          metrics[3][1] = `${(localProgress * 220).toFixed(1)} kpc interaction`;
        }
        if (phaseIndex === 4) {
          metrics[0][1] = `${(1.4 + localProgress * 2.6).toFixed(3)} proper-Mpc`;
        }

        setHud({ phaseIndex, progress: globalProgress, metrics });
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      controls.dispose();
      scene.traverse((obj: THREE.Object3D) => {
        const typedObj = obj as THREE.Object3D & {
          geometry?: THREE.BufferGeometry;
          material?: THREE.Material | THREE.Material[];
        };
        if (typedObj.geometry) {
          typedObj.geometry.dispose();
        }
        if (typedObj.material) {
          if (Array.isArray(typedObj.material)) {
            typedObj.material.forEach((mat: THREE.Material) => mat.dispose());
          } else {
            typedObj.material.dispose();
          }
        }
      });
      renderer.dispose();
      if (host.contains(renderer.domElement)) {
        host.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#01030a] text-slate-100">
      <div ref={canvasRef} className="absolute inset-0" />

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(4,17,40,0)_0%,rgba(1,3,10,0.75)_85%)]" />

      <div className="absolute inset-0 flex flex-col justify-between px-4 py-5 md:px-8 md:py-7">
        <header className="flex items-start justify-between gap-4">
          <div className="max-w-2xl space-y-2">
            <p className="text-xs uppercase tracking-[0.24em] text-cyan-300">Omega Protocol v30.0</p>
            <AnimatePresence mode="wait">
              <motion.h1
                key={PHASES[hud.phaseIndex].title}
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -10, opacity: 0 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
                className="text-xl font-medium leading-tight text-white md:text-3xl"
              >
                {PHASES[hud.phaseIndex].title}
              </motion.h1>
            </AnimatePresence>
            <motion.p
              key={`${PHASES[hud.phaseIndex].key}-summary`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="max-w-xl text-sm leading-relaxed text-slate-300 md:text-base"
            >
              {PHASES[hud.phaseIndex].summary}
            </motion.p>
          </div>

          <p className="hidden text-right text-xs leading-relaxed tracking-wide text-slate-400 md:block">
            Drag to orbit
            <br />
            Scroll to zoom
          </p>
        </header>

        <section className="grid grid-cols-2 gap-x-8 gap-y-2 text-xs text-slate-300 md:grid-cols-4 md:gap-x-10 md:text-sm">
          {hud.metrics.map(([label, value]) => (
            <motion.div
              key={label}
              animate={{ opacity: [0.65, 1, 0.65] }}
              transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
              className="space-y-0.5"
            >
              <p className="text-[11px] uppercase tracking-[0.14em] text-slate-400">{label}</p>
              <p className="font-mono text-cyan-200">{value}</p>
            </motion.div>
          ))}
        </section>

        <footer className="space-y-2">
          <div className="flex items-end justify-between text-[10px] uppercase tracking-[0.14em] text-slate-400 md:text-xs">
            {phaseTicks.map((tick) => (
              <span key={tick}>{tick}</span>
            ))}
          </div>
          <div className="h-1 w-full overflow-hidden bg-slate-900/70">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-400 via-indigo-400 to-fuchsia-400"
              animate={{ width: `${hud.progress * 100}%` }}
              transition={{ duration: 0.2, ease: "linear" }}
            />
          </div>
        </footer>
      </div>
    </div>
  );
}
